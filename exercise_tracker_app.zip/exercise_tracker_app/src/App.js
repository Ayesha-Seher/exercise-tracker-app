
import './App.css';
import Header from './components/Header';
import Features from './components/Features';
import Services from './components/Services';
import Subscribe from './components/Subscribe';
import { useState } from 'react';
import Cards from './components/Cards';
import InputForm from './components/InputForm';
// import { Route } from 'router';
import { Routes,Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import showact from './components/showact';

// import newcomponent from './components/newcomponent';

function App() {
 const [show,setShow]=useState(0)
 const[data, setData] = useState([]);
  return (
    <div className="App">
      {/* <InputForm/> */}
    {/* <InputForm  submitData = {submitData}/>
    <Cards data = {data}/> */}
<Navbar />
{show==0? (<Header setShow={setShow} />):null}
{show==1? (
  <InputForm data={data} setData={setData} setShow={setShow}/>):null }
{show==2?      <showact data={data}/>
:null}
     
      

       {/* <Features />
      <Services />
      <Subscribe /> */}
            

        
      
     
    </div>
  );
}

export default App;
