import React from 'react'

const Cards = (props) => {
    return (
        <div className='row'>
            {props.data.map((d) =>(
                <div className="card mt-4 ml-4" style={{ width: '18rem' }}>
                <div className="card-body">
                    <h5 className="card-title">{d.user_options}</h5>
                    <p className="card-username">{d.user_name}</p>
                    <p className="card-description">{d.user_description}</p>
                    <p className="card-duration">{d.user_duration}</p>
                    <p className="card-date">{d.user_date}</p>
                   
                </div>
            </div>

            ))}
            
        </div>
    )
}

export default Cards