import React, { useState } from "react";
import Header from "./Header";
import Navbar from "./Navbar";
import Subscribe from "./Subscribe";

const InputForm = (props) => {
   
    const submitData = (event) =>{
        event.preventDefault();
        props.setShow(2)
        props.setData([...props.data,inputs])
    } 
    const [inputs, setInputs] = useState("");
    const handleInputs = (event) => {
        const value = event.target.value;
        const name = event.target.name;
        setInputs((values) => ({ ...values, [name]: value }))
    }

    const options = [
        { value: '', label: '--select activity--' },
        { value: 'run', label: 'run' },
        { value: 'walk', label: 'walk' },
        { value: 'swim', label: 'swim' },
        { value: 'hike', label: 'hike' },
        { value: 'cycle ride', label: 'cycle ride' }
    ];

    return (
        <div className="form-container">
            <div className="container col-12">
                <div className="row">
            <div className="container mt-4 col-6">
                <Navbar />
                <form id="form" onSubmit={submitData}>
                    <div className="form-group">
                        <label htmlFor="name">Name:</label>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Enter name"
                            onChange={handleInputs}
                            name='user_name'
                            value={inputs.user_name} />
                    </div>
                    <div className="form-group">
                        <label htmlFor="description">Description:</label>
                        <textarea
                            type="text"
                            className="form-control"
                            placeholder="Description"
                            rows={5}
                            onChange={handleInputs}
                            name='user_description'
                            value={inputs.user_description}
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="activity_type">Activity:</label>
                        <select className="form-control" name="user_options" onChange={handleInputs}>
                            {options.map((option) => (
                                <option value={option.value} key={option.value}>{option.label}</option>
                            ))}
                        </select>
                    </div>
                    <div className="form-group">
                        <label htmlFor="duration">Duration:</label>
                        <input
                            type="time"
                            className="form-control"
                            placeholder="Enter duration"
                            onChange={handleInputs}
                            name='user_duration'
                            value={inputs.user_duration}
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="date">Date:</label>
                        <input
                            type="date"
                            className="form-control"
                            placeholder="Enter date"
                            onChange={handleInputs}
                            name='user_date'
                            value={inputs.user_date}
                        />
                    </div>
                    <button type="submit" className="btn btn-primary">
                        Submit
                    </button>
                </form>
                <button type="submit" onClick={() => props.setShow(1)} className="btn btn-primary">
                    Back to Home
                </button>
            </div>
           </div>
           </div>
           <Subscribe />
           </div>
    );
};

export default InputForm;

