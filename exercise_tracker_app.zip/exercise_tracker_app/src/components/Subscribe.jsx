import React from 'react';

const Subscribe = () => {
  return (
    <div id='subscribe'>
        <h3>Subscribe</h3>
        <div className='subscribe-input'>
            <input type='email' placeholder='fitnessfrenzy@gmail.com'/>
            <a href='#'>Continue</a>
      
        </div>
        
    <footer>
      <div className='footer-links'>
        <a href='#'>About Us</a>
        <a href='#'>Contact Us</a>
        <a href='#'>FAQ</a>
        <a href='#'>Privacy Policy</a>
      </div>
      <p>Copyright &copy; {new Date().getFullYear()} Your Company Name</p>
    </footer>
    </div>
  )

}

export default Subscribe;
