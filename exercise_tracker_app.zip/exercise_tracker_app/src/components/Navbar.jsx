import React from 'react';
import logo from '../images/logo1.png';
import { Link } from 'react-scroll';

const Navbar = (props) => {
   
  return (
    <div>
        <nav>
            <Link to='main' className='logo'  duration={1000}>
                <img src = {logo} alt='logo'/>
            </Link>
            <input className='menu-btn' type = 'checkbox' id='menu-btn' />
            <label className='menu-icon' for = 'menu-btn'>
                <span className='nav-icon'></span>
            </label>
            
            <ul className='menu'>
                <li><Link  to='main' className='active' duration={1000}>Home</Link></li>
                <li><Link to='features' duration={1000}>Features</Link></li>
                <li><Link to='services'  duration={1000}>Services</Link></li>
                <li><Link to='subscribe'  duration={1000}>Subscribe</Link></li>
                {/* <li><Link to='form'> Add Activity </Link></li> */}
            </ul>
            
        </nav>
    </div>
  )                      
}

export default Navbar;