import React from 'react'
import Cards from './Cards'
import Navbar from './Navbar'
import Subscribe from './Subscribe'
import Header from './Header'


function showact(props) {
    console.log (props.data)
  return (
    <div>
        <div>
            <Header/>
    <Navbar/>
  <div className="col-6 ">
  <div className="row">

<Cards data={props.data} />
</div>
</div>
</div>
<Subscribe/>
</div>
  )
}

export default showact