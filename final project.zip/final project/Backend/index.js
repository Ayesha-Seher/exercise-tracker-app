const express = require("express");
const mongoose = require("mongoose");                         
const bodyparser = require("body-parser");                    
const cors = require("cors");                                 
const app = express();
// const mySchema = require("./model/cardmodel");
const cardcontroller = require("./controllers/cardcontroller");

// Port Connection established
app.listen(8000, () => {
	console.log("Port is connected ");
});
app.use(cors());

// Databse created and connected
mongoose.set("strictQuery", false);
mongoose
  .connect("mongodb://127.0.0.1:27017/my_database", { useNewUrlParser: true })
  .then(() => {
    console.log("db is connected");
  });
	
mongoose.connection.once("open", () => {
	console.log("Connection done");
});
app.use(bodyparser.json());
app.use("/exe", cardcontroller);