const express = require("express");
// const cardmodel = require("../model/cardmodel");
const router = express.Router();
const cardmodel = require("../model/cardmodel");

router.post("/", async (req, res) => {
    try {
        const card = await cardmodel(req.body);
        card.save();
        res.send(card);
    } catch {
        // console.log(error);
    }
});

//Get all data
router.get("/", async (req, res) => {
    const card = await cardmodel.find();
    res.send(card);
});
//get data by id
router.get("/:id", async (req, res) => {
    const card = await cardmodel.findById(req.params.id);
    res.send(card);
});
//for delete card
router.delete("/:id", (req, res) => {
    let getid = req.params.id;
    console.log(getid);
    cardmodel.findByIdAndDelete(getid)

        .then((card) => {
            res.send(card);
        })
        .catch((err) => {
            res.status(404).send(err.message);
        });
});

router.put("/:id", async (req, res) => {
    const card = await cardmodel.findByIdAndUpdate(req.params.id, {
        $set: req.body,
    });

    res.send(card);
});
module.exports = router;