const mongoose = require("mongoose");
const my_schema = mongoose.Schema({
    name: { required: true, type: String },
    description: { required: true, type: String },
    activity: { required: true, type: String },
    duration: { required: true, type: String },
    date: { required: true, type: String },
});
module.exports = mongoose.model("exercise app", my_schema);