
import './App.css';
import Header from './components/Header';
import Features from './components/Features';
import Services from './components/Services';
import Subscribe from './components/Subscribe';
// import { Route } from 'router';
import Navbar from './components/Navbar';

// import newcomponent from './components/newcomponent';

function App() {
    const [inputs, setInputs] = useState({
        name: '',
        description: '',
        activity: '',
        duration: '',
        date: ''
      });
    
      const submitData = (data) => {
        console.log(data);
      };
  return (
    <div className="App">
        
     
         <Navbar/>
         <Header/>
        <Features />
      <Services />
      <Subscribe /> 

 
    </div>
  );
}

export default App;
