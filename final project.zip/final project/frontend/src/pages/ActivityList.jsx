import React from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../App.css";

const ActivityList = (props) => {
  const navigate = useNavigate();
 
  return (
    <div id="showcard">
      {props.data.map((d) => (
        <div className="card-body">
          <p className="card_name">{d.name}</p>
          <p className="card-description">{d.description}</p>
          <p className="card-title">{d.activity}</p>
          <p className="card-duration">{d.duration}</p>
          <p className="card-date">{d.date}</p>

          {/********************** Buttons CRUD*************************/}
          <button className="btn" onClick={() => {
            props.edit(d._id);
            navigate("/ActivityForm");
            }}>Edit</button>
          <button className="btn" onClick={() => {
              axios
                .delete(`http://localhost:4000/card/${d._id}`)
                .then(() => console.log("data deleted"))
                .catch((err) => alert("carddelete", err));
            }}>Delete</button>
        </div>
      ))}
    </div>
  );
};

export default ActivityList;
