import React from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../App.css";

const ActivityForm = (props) => {

  const navigation = useNavigate();
////////////////////////////////////// Handle the form Inputs  ////////////////////////////////////////////
  const handleInputs = (event) => {
    const value = event.target.value;
    const name = event.target.name;
    props.setinputs((values) => ({ ...values, [name]: value }));
  };
//////////////////////////////////// Handle the Submit  ///////////////////////////////////////////////////
  const handleSubmit = (event) => {
    event.preventDefault();
    props.submitData(props.inputs);
    navigation("/ActivityList");
    showcard();
  };

  //////////////////////////////////////////////////////////////////////////////////////////////////////
  const showcard = () => {
    if (props.show) {
      axios
        .put(`http://localhost:4000/card/${props.editData}`, {
          name: props.inputs.name,
          description: props.inputs.description,
          activity: props.inputs.activity,
          duration: props.inputs.duration,
          date: props.inputs.date
        })
        .then((res) => console.log("ress", res))
        .catch((err) => alert("CardPost", err));

      props.api();
      props.setShow(false);
    } else {
      axios
        .post("http://localhost:4000/card", {
          name: props.inputs.name,
          description: props.inputs.description,
          activity: props.inputs.activity,
          duration: props.inputs.duration,
          date: props.inputs.date
        })
        .then((res) => console.log("ress", res))
        .catch((err) => alert("CardPost", err));
      
    }
  };
  console.log("data posted",showcard);

  /////////////////////////////// User_Activity Options  ///////////////////////////////////////////
  const activity = [
    { value: "", label: "--select activity--" },
    { value: "run", label: "run" },
    { value: "walk", label: "walk" },
    { value: "swim", label: "swim" },
    { value: "hike", label: "hike" },
    { value: "cycle ride", label: "cycle ride" },
  ];
/////////////////////////////////////////////  Return ///////////////////////////////////////////////
  return (
    <div className="activity_form">
      <div className="form_design">
        <form onSubmit={handleSubmit} id="form_design">
          <div className="form-group">
            <label htmlFor="name">Name:</label>
            <input
              style={{ width: "100%" }}
              type="text"
              className="form-control"
              placeholder="Enter name"
              onChange={handleInputs}
              name="name"
              value={props.inputs.
                name}
            />
          </div>
          <div className="form-group">
            <label htmlFor="description">Description:</label>
            <textarea
              type="text"
              className="form-control"
              placeholder="Description"
              rows={5}
              onChange={handleInputs}
              name="description"
              value={props.inputs.description}
            />
          </div>

          <div>
            <label htmlFor="activity_type">Activity:</label>
            <select
              className="form-control"
              name="activity"
              onChange={handleInputs}
              value={props.inputs.option}
            >
              {activity.map((option) => (
                <option value={option.value}>{option.label}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="duration">Duration:</label>
            <input
              type="time"
              className="form-control"
              placeholder="Enter duration"
              onChange={handleInputs}
              name="duration"
              value={props.inputs.duration}
            />
          </div>
          <div className="form-group">
            <label htmlFor="date">Date:</label>
            <input
              type="date"
              className="form-control"
              placeholder="Enter date"
              onChange={handleInputs}
              name="date"
              value={props.inputs.date}
            />
          </div>
          <button type="submit" className="btn">
            Submit
          </button>
        </form>
      </div>
    </div>
  );
};

export default ActivityForm;
