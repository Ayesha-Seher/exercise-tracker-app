import React from 'react';
import logo from '../images/logo1.png';
import { Link } from 'react-scroll';
import { NavLink, Switch, Route } from 'react-router-dom';
import ActivityForm from '.src/pages/ActivityForm';
import ActivityList from '.src/pages/ActivityList';

const Navbar = ({ children }) => {
  const menuItem = [
    {
      path: '/ActivityForm',
      name: 'Activity Form',
      icon: <i className="fas fa-edit"></i>
    },
    {
      path: '/ActivityList',
      name: 'Activity List',
      icon: <i className="fas fa-list"></i>
    }
  ];

  return (
    <div>
      <nav>
        <Link to="main" className="logo" duration={1000}>
          <img src={logo} alt="logo" />
        </Link>
        <input className="menu-btn" type="checkbox" id="menu-btn" />
        <label className="menu-icon" htmlFor="menu-btn">
          <span className="nav-icon"></span>
        </label>

        <ul className="menu">
          <li>
            <Link to="main" className="active" duration={1000}>
              Home
            </Link>
          </li>
          <li>
            <Link to="features" duration={1000}>
              Features
            </Link>
          </li>
          <li>
            <Link to="services" duration={1000}>
              Services
            </Link>
          </li>
          <li>
            <Link to="subscribe" duration={1000}>
              Subscribe
            </Link>
          </li>
        </ul>

        <div className="links">
          {menuItem.map((item, index) => (
            <NavLink
              key={index}
              to={item.path}
              className="link"
              activeClassName="active"
            >
              <div className="icon">{item.icon}</div>
              <div className="link_text">{item.name}</div>
            </NavLink>
          ))}
        </div>
      </nav>

      <main>
        <Switch>
          <Route path="/ActivityForm" component={ActivityForm} />
          <Route path="/ActivityList" component={ActivityList} />
          <Route path="/" exact>
            {children}
          </Route>
        </Switch>
      </main>
    </div>
  );
};

export default Navbar;
