import React from 'react';
import featureimage from '../images/Frame 19.png'

const Features = () => {
  return (
    <div id='features'>
        <div className='features-model'>
            <img src={featureimage} alt ='feature-image' />
        </div>
        <div className='features-text'>
            <h2>Features</h2>
            <h3> A <span> personalized</span> Experience</h3>
            <p>When it’s about tracking the user’s daily activity and further evaluating the user’s fitness, the application needs to have user’s personal information like, age, height, gender, and weight.</p>
            <button>View More Features</button>
        </div>
    </div>
  )
}

export default Features;