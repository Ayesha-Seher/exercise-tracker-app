import React from "react";
import { useNavigate } from "react-router-dom";
import Features from "./Features";
import Navbar from "./Navbar";
import Services from "./Services";
import Subscribe from "./Subscribe";

const Header = (props) => {
  const navigate=useNavigate();
  return (
    <div>
    <div id="main">
      {/* <Navbar /> */}
      
      <div className="name">
        <h1>
          It's a <span> FitnessFrenzy</span> Website
        </h1>
        <p className="details">
        The app allows users to record and track their daily physical activity, including exercises, workouts, and other physical activities
        </p>
        <div className="header-btns">
          <button  onClick={()=>{props.setShow(true)}}className="cv-btn">
            Add Activity!
          </button>
          <a href="#" className="cv-btn1">
            Download App
          </a>
        </div>
      </div>
      <div className='arrow'></div>
     

    </div>
    <div><div className='f-heading'>
        <h1>Features</h1>
        <p>Hey there are our gym website feature</p>
      </div> </div>
      <div>
      <Features />
      <Services />
      <Subscribe />
      </div>
    </div>
  );
};

export default Header;
