import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import { useState, useEffect } from "react";
import ActivityForm from "./pages/ActivityForm";
import ActivityList from "./pages/ActivityList";
import axios from "axios";
import Navbar from "./components/Navbar";


function main() {

  const [data, setData] = useState([]);
  const submitData = (s) => {
    setData([...data, s])
  }

  ////////////////////////////////////////////////  empty /////////////////////////////////
  const empty = {
    name: "",
    discription: " ",
    option: " ",
    duration: " ",
    date: "",
  };

  ////////////////////////////////////// inputs /////////////////////////////////
  const [inputs, setInputs] = useState(empty);
  const [show, setShow] = useState(false)
  //for getdata
  const api = () => {
    axios
      .get("http://localhost:4000/card")
      .then((res) => setData(res.data))
      .catch((err) => alert("cardFetch", err));
  };

  useEffect(() => {
    api();
  }, []);
  console.log("data", data);


  /////////////////    Edit_DATA   //////////////////////////////////////

  const [editData, seteditData] = useState(0);
  const edit = (id) => {
    fetch(`http://localhost:4000/card/${id}`)
      .then((data1) => data1.json())
      .then((res) => setInputs(res));
    setShow(true);
    seteditData(id);
    console.log(show)
  };
  
  return (
    <div>
      <BrowserRouter>
        <Navbar>
          <Routes>
            <Route path="/ActivityForm" element={<ActivityForm editData={editData} inputs={inputs} setinputs={setInputs} submitData={submitData} show={show} setShow={setShow} api={api} />} />
            <Route path="/ActivityList" element={<ActivityList edit={edit} data={data} api={api} />} />
          </Routes>
        </Navbar>
      </BrowserRouter>

    </div>
  );
}

export default main;
